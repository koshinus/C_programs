#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main()
{

	int n,i;
	double ar[] = {3.4,2.3,4.555};
	
	printf("Enter number: ");
	scanf("%d", &n);
	
	printf("%d\n", sizeof(ar));
	return 0;
}