#include <stdio.h>

void PrintTime (Time time)
{	
	if ((Time.hours>23)||(Time.minutes>59)||(Time.seconds>59))
	{
	printf("You must enter the time correctly!")
	main()
	}
	printf("%d%d%d",Time.hours,Time.minutes,Time.seconds);
}

int main()
{
struct Time
		{ int hours;
		int minutes;
		int seconds; };

	printf("Enter the time: ");
	scanf("%d%d%d\n",Time.hours,Time.minutes,Time.seconds);
	t=
	PrintTime (Time t)
	}