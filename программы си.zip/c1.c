#include <stdio.h> 
#include <math.h> 
#include <stdlib.h>

int main()
{
double c, i=0;
c=1.0/4;
printf("%lf\n",c);
if (c==i) printf("1");
else printf("0\n");
int x;
x=3/2;
printf("%d\n",x);




return 0;
}